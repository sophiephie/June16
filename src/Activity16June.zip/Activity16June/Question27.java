package Activity16June;

public class Question27 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Not sure how to

	}

}
