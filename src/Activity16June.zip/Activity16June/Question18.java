package Activity16June;

public class Question18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Unclear question, not sure what kind of array
	}

}
