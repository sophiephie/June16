package Activity16June;

public class Question20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] elements = new int[] { 1, 2, 3, 4, 6 };
		for (int i = 0; i < elements.length; i++) {
			if (elements[i] % 2 == 0) {
				System.out.println("Even number : " + elements[i]);
			} else {
				System.out.println("Odd number : " + elements[i]);

			}
		}
	}

}
